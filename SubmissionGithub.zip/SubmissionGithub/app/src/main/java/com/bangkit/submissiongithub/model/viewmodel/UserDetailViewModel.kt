package com.bangkit.submissiongithub.model.viewmodel

import android.util.Log
import androidx.lifecycle.*
import com.bangkit.submissiongithub.api.ApiConfig
import com.bangkit.submissiongithub.model.DetailResponse
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserDetailViewModel : ViewModel() {

    private val listDetail = MutableLiveData<DetailResponse>()
    val detail: LiveData<DetailResponse> = listDetail

    private val isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = isLoading

    companion object {
        private const val TAG = "UserDetailModel"
    }

    fun getItemsItem(login: String) {
        isLoading.value = true
        ApiConfig.getApiService().getUserDetail(login).enqueue(object : Callback<DetailResponse> {
            override fun onResponse(call: Call<DetailResponse>, response: Response<DetailResponse>) {
                isLoading.value = false
                if (response.isSuccessful) {
                    listDetail.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailResponse>, t: Throwable) {
                isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }
}