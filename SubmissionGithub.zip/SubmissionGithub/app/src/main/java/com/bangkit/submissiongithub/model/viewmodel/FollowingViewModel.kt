package com.bangkit.submissiongithub.model.viewmodel

import android.util.Log
import androidx.lifecycle.*
import com.bangkit.submissiongithub.api.ApiConfig
import com.bangkit.submissiongithub.model.ItemsItem
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class FollowingViewModel : ViewModel() {

    private val listFollowing = MutableLiveData<List<ItemsItem>>()
    val following: LiveData<List<ItemsItem>> = listFollowing

    private val isLoading = MutableLiveData<Boolean>()
    val loading: LiveData<Boolean> = isLoading

    companion object {
        private const val TAG = "FollowingViewModel"
    }

    fun getFollowing(username: String) {
        isLoading.value = true
        ApiConfig.getApiService().getUserFollowings(username).enqueue(object : Callback<List<ItemsItem>> {
            override fun onResponse(
                call: Call<List<ItemsItem>>,
                response: Response<List<ItemsItem>>
            ) { isLoading.value = false
                if (response.isSuccessful) {
                    listFollowing.value = response.body()
                } else {
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<List<ItemsItem>>, t: Throwable) {
                isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }
}